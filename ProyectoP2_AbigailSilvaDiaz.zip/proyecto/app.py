from flask import Flask, render_template,request, jsonify, session, redirect, url_for, send_file
from bd_ticketturno import NivelEducativo, Municipio, Asunto, Tramite, Admin
import qrcode
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from io import BytesIO

app = Flask(__name__)
app.secret_key = "si"
# Configurar conexión a la base de datos
#app.config['MYSQL_HOST'] = 'localhost'
#app.config['MYSQL_USER'] = 'root'
#app.config['MYSQL_PASSWORD'] = 'AbigailDiaz19/'
#app.config['MYSQL_DB'] = 'db_ticketturno'


@app.route('/')
def home():
    niveles = NivelEducativo.listar_niveles()
    municipios = Municipio.listar_municipios()
    asuntos = Asunto.listar_asuntos()
    return render_template('index.html', niveles=niveles, municipios=municipios, asuntos=asuntos)

# Ruta para manejar datos del formulario y almacenarlos en la base de datos
@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        # Recibir los datos del formulario
        nombrecomp = request.form['nombrecomp']
        curp = request.form['curp']
        nombre = request.form['nombre']
        paterno = request.form['paterno']
        materno = request.form['materno']
        telefono = request.form['telefono']
        celular = request.form['celular']
        correo = request.form['correo']
        nivel_educativo = request.form['nivelaingresar']
        municipio = request.form['municipio']
        asunto = request.form['asunto']

        # Conexión a la base de datos y ejecución de la consulta
        tramite = Tramite.crear_tramite(nombrecomp, curp, nombre, paterno, materno, telefono, celular, correo, nivel_educativo, municipio, asunto)
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data({'curp': curp, 'numero_turno': tramite})
        qr.make(fit=True)

        img = qr.make_image(fill='black', back_color='white')
        qr_code_filename = f"qr.png"
        img.save(qr_code_filename)

        pdf_io = BytesIO()
        c = canvas.Canvas(pdf_io, pagesize=letter)
        width, height = letter

        # Escribir datos en el PDF
        c.drawString(100, height - 50, f'Número de Turno: {tramite}')
        c.drawString(100, height - 70, f'Nombre Completo: {nombrecomp}')
        c.drawString(100, height - 90, f'CURP: {curp}')
        c.drawString(100, height - 110, f'Nombre: {nombre}')
        c.drawString(100, height - 130, f'Apellido Paterno: {paterno}')
        c.drawString(100, height - 150, f'Apellido Materno: {materno}')
        c.drawString(100, height - 170, f'Teléfono: {telefono}')
        c.drawString(100, height - 190, f'Celular: {celular}')
        c.drawString(100, height - 210, f'Correo: {correo}')
        c.drawString(100, height - 230, f'Nivel Educativo: {nivel_educativo}')
        c.drawString(100, height - 250, f'Municipio: {municipio}')
        c.drawString(100, height - 270, f'Asunto: {asunto}')
        c.drawString(100, height - 290, 'Tu Código QR:')
        c.drawImage(qr_code_filename, 100, height - 350, width=100, height=100)
        c.save()
        pdf_io.seek(0)
        return send_file(pdf_io, as_attachment=True, download_name=f"comprobante.pdf", mimetype='application/pdf')

@app.route('/buscar', methods=['POST'])
def buscar():
    numero_turno = request.form.get('numero_turno')
    municipio = request.form.get('municipio_turno')
    tramite = Tramite.buscar_por_id(numero_turno, municipio)
    if tramite:
        municipios = Municipio.listar_municipios()
        asuntos = Asunto.listar_asuntos()
        niveles = NivelEducativo.listar_niveles()
        return render_template('datos.html', tramite=tramite, municipios=municipios, asuntos=asuntos, niveles=niveles)
    else:
        return redirect(url_for('home'))
    
@app.route('/actualizar', methods=['POST'])
def actualizar():
    if request.method == 'POST':
        # Recibir los datos del formulario
        numero = request.form['numero_turno']
        nombrecomp = request.form['nombrecomp']
        curp = request.form['curp']
        nombre = request.form['nombre']
        paterno = request.form['paterno']
        materno = request.form['materno']
        telefono = request.form['telefono']
        celular = request.form['celular']
        correo = request.form['correo']
        nivel_educativo = request.form['nivelaingresar']
        municipio = request.form['municipio']
        asunto = request.form['asunto']

        # Conexión a la base de datos y ejecución de la consulta
        Tramite.actualizar_tramite(numero, municipio, nombrecomp, curp, nombre, paterno, materno, telefono, celular, correo, nivel_educativo_id = nivel_educativo, asunto_id=asunto)
        tramite = Tramite.buscar_por_id(numero, municipio)
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data({'curp': curp, 'numero_turno': tramite})
        qr.make(fit=True)

        img = qr.make_image(fill='black', back_color='white')
        qr_code_filename = f"qr.png"
        img.save(qr_code_filename)

        pdf_io = BytesIO()
        c = canvas.Canvas(pdf_io, pagesize=letter)
        width, height = letter

        # Escribir datos en el PDF
        c.drawString(100, height - 50, f'Número de Turno: {numero}')
        c.drawString(100, height - 70, f'Nombre Completo: {nombrecomp}')
        c.drawString(100, height - 90, f'CURP: {curp}')
        c.drawString(100, height - 110, f'Nombre: {nombre}')
        c.drawString(100, height - 130, f'Apellido Paterno: {paterno}')
        c.drawString(100, height - 150, f'Apellido Materno: {materno}')
        c.drawString(100, height - 170, f'Teléfono: {telefono}')
        c.drawString(100, height - 190, f'Celular: {celular}')
        c.drawString(100, height - 210, f'Correo: {correo}')
        c.drawString(100, height - 230, f'Nivel Educativo: {nivel_educativo}')
        c.drawString(100, height - 250, f'Municipio: {municipio}')
        c.drawString(100, height - 270, f'Asunto: {asunto}')
        c.drawString(100, height - 290, 'Tu Código QR:')
        c.drawImage(qr_code_filename, 100, height - 350, width=100, height=100)
        c.save()
        pdf_io.seek(0)
        return send_file(pdf_io, as_attachment=True, download_name=f"comprobante.pdf", mimetype='application/pdf')

@app.route('/login', methods=['get', 'post'])
def login():
    if request.method=='POST':
        usuario = request.form.get('usuario')
        password = request.form.get('password')
        admin = Admin.buscar_por_user(usuario)
        if admin:
            if admin['password'] == password:
                session['admin'] = True
                return redirect(url_for('admin'))
            else:
                return render_template('login.html', mensaje='usuario y/o contraseña incorrectos')
        else:
            return render_template('login.html', mensaje='usuario y/o contraseña incorrectos')
        
    return render_template('login.html', mensaje='')

@app.route('/logout')
def logout():
    session['admin'] = False
    return redirect(url_for('home'))

@app.route('/admin')
def admin():
    if session['admin']:
        return render_template('admin.html')
    else:
        return redirect(url_for('home'))

@app.route('/tramites', methods=['POST', 'GET'])
def tramites():
    if session['admin']:
        tramites = None
        if request.method=='GET':
            tramites = Tramite.listar_tramites()
        elif request.method=='POST':
            query = request.form['search_query']
            tramites = Tramite.listar_tramites_variable(query)
        print(tramites)
        return render_template('tramites.html', tramites=tramites)
    else:
        return redirect(url_for('home'))
    
@app.route('/cambiar/<int:id>/<int:municipio>')
def cambiar(id, municipio):
    if session['admin']:
        tramite = Tramite.buscar_por_id(id, municipio)
        estado = 'pendiente'
        if tramite['estado'] == 'pendiente':
            estado = 'resuelto'
        Tramite.actualizar_tramite(id, municipio, estado=estado)
        return redirect(url_for('tramites'))
    else:
        return redirect(url_for('home'))

@app.route('/eliminar/<int:id>/<int:municipio>')
def eliminar(id, municipio):
    if session['admin']:
        Tramite.eliminar_tramite(id, municipio)
        return redirect(url_for('tramites'))
    else:
        return redirect(url_for('home'))

@app.route('/catalogos')
def catalogos():
    if session['admin']:
        niveles = NivelEducativo.listar_niveles()
        municipios = Municipio.listar_municipios()
        asuntos = Asunto.listar_asuntos()
        return render_template('catalogo.html', niveles=niveles, municipios=municipios, asuntos=asuntos)
    else:
        return redirect(url_for('home'))

@app.route('/crear_nivel/<string:nivel>')
def crear_nivel(nivel):
    if session['admin']:
        NivelEducativo.crear_nivel(nivel)
        return redirect(url_for('catalogos'))
    else:
        return redirect(url_for('home'))

@app.route('/actualizar_nivel/<int:id>', methods=['POST'])
def actualizar_nivel(id):
    if session['admin']:
        nivel = request.form['nivel']
        NivelEducativo.actualizar_nivel(id, nivel)
        return redirect(url_for('catalogos'))
    else:
        return redirect(url_for('home'))

@app.route('/eliminar_nivel/<int:id>', methods=['GET'])
def eliminar_nivel(id):
    if session['admin']:
        NivelEducativo.eliminar_nivel(id)
        return redirect(url_for('catalogos'))
    else:
        return redirect(url_for('home'))

@app.route('/crear_municipio/<string:municipio>')
def crear_municipio(municipio):
    if session['admin']:
        Municipio.crear_municipio(municipio)
        return redirect(url_for('catalogos'))
    else:
        return redirect(url_for('home'))

@app.route('/actualizar_municipio/<int:id>', methods=['POST'])
def actualizar_municipio(id):
    if session['admin']:
        municipio = request.form['municipio']
        Municipio.actualizar_municipio(id, municipio)
        return redirect(url_for('catalogos'))
    else:
        return redirect(url_for('home'))

@app.route('/eliminar_municipio/<int:id>', methods=['GET'])
def eliminar_municipio(id):
    if session['admin']:
        Municipio.eliminar_municipio(id)
        return redirect(url_for('catalogos'))
    else:
        return redirect(url_for('home'))
@app.route('/crear_asunto/<string:asunto>')
def crear_asunto(asunto):
    if session['admin']:
        Asunto.crear_asunto(asunto)
        return redirect(url_for('catalogos'))
    else:
        return redirect(url_for('home'))

@app.route('/actualizar_asunto/<int:id>', methods=['POST'])
def actualizar_asunto(id):
    if session['admin']:
        asunto = request.form['asunto']
        Asunto.actualizar_asunto(id, asunto)
        return redirect(url_for('catalogos'))
    else:
        return redirect(url_for('home'))

@app.route('/eliminar_asunto/<int:id>', methods=['GET'])
def eliminar_asunto(id):
    if session['admin']:
        Asunto.eliminar_asunto(id)
        return redirect(url_for('catalogos'))
    else:
        return redirect(url_for('home'))

@app.route('/dashboard/<int:municipio_id>')
def dashboard(municipio_id = 0):
    if not session['admin']:
        return redirect(url_for('home'))
    tramites = Tramite.listar_tramites()
    if not municipio_id == 0:
        tramites = [tramite for tramite in tramites if tramite['municipio_id'] == municipio_id]
    municipios = Municipio.listar_municipios()
    tramites_pendientes = [tramite for tramite in tramites if tramite['estado']=='pendiente']
    tramites_resueltos = [tramite for tramite in tramites if tramite['estado']=='resuelto']
    
    return render_template('dashboard.html', 
                           tramites_pendientes=tramites_pendientes,
                           tramites_resueltos=tramites_resueltos, municipios = municipios)

@app.route('/api/tramites/<int:municipio_id>')
def api_tramites(municipio_id = 0):
    
    tramites = Tramite.listar_tramites()
    if not municipio_id == 0:
        tramites = [tramite for tramite in tramites if tramite['municipio_id'] == municipio_id]
    tramites_pendientes = [tramite for tramite in tramites if tramite['estado']=='pendiente']
    tramites_resueltos = [tramite for tramite in tramites if tramite['estado']=='resuelto']
    print(tramites)

    return jsonify({
        'pendientes': tramites_pendientes,
        'resueltos': tramites_resueltos
    })
if __name__ == '__main__':
    app.run(debug=True)