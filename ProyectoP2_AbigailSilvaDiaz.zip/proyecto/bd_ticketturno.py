from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, func
from sqlalchemy.orm import declarative_base, sessionmaker, relationship

# Conexión a la base de datos MySQL
DATABASE_URL = "mysql+pymysql://root:AbigailDiaz19/@localhost/db_ticketturno"
engine = create_engine(DATABASE_URL, echo=False)

# Base del ORM
Base = declarative_base()

# Sesión para interactuar con la base de datos
Session = sessionmaker(bind=engine)
session = Session()

class NivelEducativo(Base):
    __tablename__ = 'niveles_educativos'

    id = Column(Integer, primary_key=True, autoincrement=True)
    nivel = Column(String(50), nullable=False)

    @staticmethod
    def crear_nivel(nivel):
        nuevo_nivel = NivelEducativo(nivel=nivel)
        session.add(nuevo_nivel)
        session.commit()

    @staticmethod
    def listar_niveles():
        niveles = session.query(NivelEducativo).all()
        return [{"id": nivel.id, "nivel": nivel.nivel} for nivel in niveles]

    @staticmethod
    def buscar_por_id(id):
        nivel = session.query(NivelEducativo).filter_by(id=id).first()
        return {"id": nivel.id, "nivel": nivel.nivel} if nivel else None

    @staticmethod
    def actualizar_nivel(id, nuevo_nivel):
        nivel = session.query(NivelEducativo).filter_by(id=id).first()
        if nivel:
            nivel.nivel = nuevo_nivel
            session.commit()

    @staticmethod
    def eliminar_nivel(id):
        nivel = session.query(NivelEducativo).filter_by(id=id).first()
        if nivel:
            session.delete(nivel)
            session.commit()

class Municipio(Base):
    __tablename__ = 'municipios'

    id = Column(Integer, primary_key=True, autoincrement=True)
    municipio = Column(String(100), nullable=False)

    @staticmethod
    def crear_municipio(nombre_municipio):
        nuevo_municipio = Municipio(municipio=nombre_municipio)
        session.add(nuevo_municipio)
        session.commit()

    @staticmethod
    def listar_municipios():
        municipios = session.query(Municipio).all()
        return [{"id": municipio.id, "municipio": municipio.municipio} for municipio in municipios]

    @staticmethod
    def buscar_por_id(id):
        municipio = session.query(Municipio).filter_by(id=id).first()
        return {"id": municipio.id, "municipio": municipio.municipio} if municipio else None

    @staticmethod
    def actualizar_municipio(id, nuevo_nombre):
        municipio = session.query(Municipio).filter_by(id=id).first()
        if municipio:
            municipio.municipio = nuevo_nombre
            session.commit()

    @staticmethod
    def eliminar_municipio(id):
        municipio = session.query(Municipio).filter_by(id=id).first()
        if municipio:
            session.delete(municipio)
            session.commit()

class Asunto(Base):
    __tablename__ = 'asuntos'

    id = Column(Integer, primary_key=True, autoincrement=True)
    asunto = Column(String(100), nullable=False)

    @staticmethod
    def crear_asunto(asunto_nombre):
        nuevo_asunto = Asunto(asunto=asunto_nombre)
        session.add(nuevo_asunto)
        session.commit()

    @staticmethod
    def listar_asuntos():
        asuntos = session.query(Asunto).all()
        return [{"id": asunto.id, "asunto": asunto.asunto} for asunto in asuntos]

    @staticmethod
    def buscar_por_id(id):
        asunto = session.query(Asunto).filter_by(id=id).first()
        return {"id": asunto.id, "asunto": asunto.asunto} if asunto else None

    @staticmethod
    def actualizar_asunto(id, nuevo_asunto):
        asunto = session.query(Asunto).filter_by(id=id).first()
        if asunto:
            asunto.asunto = nuevo_asunto
            session.commit()

    @staticmethod
    def eliminar_asunto(id):
        asunto = session.query(Asunto).filter_by(id=id).first()
        if asunto:
            session.delete(asunto)
            session.commit()

class Admin(Base):
    __tablename__ = 'admins'

    usuario = Column(String(20), primary_key=True)
    contraseña = Column(String(80), nullable=False)

    @staticmethod
    def crear_admin(user, password):
        nuevo_admin = Admin(usuario=user, contraseña=password)
        session.add(nuevo_admin)
        session.commit()

    @staticmethod
    def buscar_por_user(user):
        admin = session.query(Admin).filter_by(usuario=user).first()
        return {"user": admin.usuario, "password": admin.contraseña} if admin else None

class Tramite(Base):
    __tablename__ = 'tramite'

    id = Column(Integer, primary_key=True)
    nombrecomp = Column(String(255))
    curp = Column(String(18))
    nombre = Column(String(100))
    paterno = Column(String(100))
    materno = Column(String(100))
    telefono = Column(String(10))
    celular = Column(String(10))
    correo = Column(String(100))
    estado = Column(String(100))
    nivel_educativo_id = Column(Integer, ForeignKey('niveles_educativos.id'))
    municipio_id = Column(Integer, ForeignKey('municipios.id'), primary_key=True)
    asunto_id = Column(Integer, ForeignKey('asuntos.id'))

    nivel_educativo = relationship("NivelEducativo", backref="tramites")
    municipio = relationship("Municipio", backref="tramites")
    asunto = relationship("Asunto", backref="tramites")

    @staticmethod
    def crear_tramite(nombrecomp, curp, nombre, paterno, materno, telefono, celular, correo,
                      nivel_educativo_id, municipio_id, asunto_id):
        # Consultar el ID más alto para el municipio_id especificado
        max_id_query = session.query(func.coalesce(func.max(Tramite.id), 0)).filter_by(municipio_id=municipio_id).scalar()
        nuevo_id = max_id_query + 1
        
        nuevo_tramite = Tramite(
            id=nuevo_id,
            nombrecomp=nombrecomp,
            curp=curp,
            nombre=nombre,
            paterno=paterno,
            materno=materno,
            telefono=telefono,
            celular=celular,
            correo=correo,
            estado='pendiente',
            nivel_educativo_id=nivel_educativo_id,
            municipio_id=municipio_id,
            asunto_id=asunto_id
        )
        session.add(nuevo_tramite)
        session.commit()
        return nuevo_id

    @staticmethod
    def listar_tramites():
        tramites = session.query(Tramite).all()
        return [{
            "id": tramite.id,
            "nombrecomp": tramite.nombrecomp,
            "curp": tramite.curp,
            "nombre": tramite.nombre,
            "paterno": tramite.paterno,
            "materno": tramite.materno,
            "telefono": tramite.telefono,
            "celular": tramite.celular,
            "correo": tramite.correo,
            "estado": tramite.estado,
            "nivel_educativo_id": tramite.nivel_educativo_id,
            "municipio_id": tramite.municipio_id,
            "asunto_id": tramite.asunto_id
        } for tramite in tramites]

    @staticmethod
    def buscar_por_id(id, municipio_id):
        tramite = session.query(Tramite).filter_by(id=id, municipio_id=municipio_id).first()
        return {
            "id": tramite.id,
            "nombrecomp": tramite.nombrecomp,
            "curp": tramite.curp,
            "nombre": tramite.nombre,
            "paterno": tramite.paterno,
            "materno": tramite.materno,
            "telefono": tramite.telefono,
            "celular": tramite.celular,
            "correo": tramite.correo,
            "estado": tramite.estado,
            "nivel_educativo_id": tramite.nivel_educativo_id,
            "municipio_id": tramite.municipio_id,
            "asunto_id": tramite.asunto_id
        } if tramite else None

    @staticmethod
    def listar_tramites_variable(query):
        # Filtrar por CURP o Nombre (esto puede incluir el nombre, apellido paterno o materno)
        tramites = session.query(Tramite).filter(
            (Tramite.curp.like(f'%{query}%')) | 
            (Tramite.nombre.like(f'%{query}%')) | 
            (Tramite.paterno.like(f'%{query}%')) | 
            (Tramite.materno.like(f'%{query}%'))
        ).all()
        
        # Convertir los resultados a un formato de diccionario
        return [{
            "id": tramite.id,
            "nombrecomp": tramite.nombrecomp,
            "curp": tramite.curp,
            "nombre": tramite.nombre,
            "paterno": tramite.paterno,
            "materno": tramite.materno,
            "telefono": tramite.telefono,
            "celular": tramite.celular,
            "correo": tramite.correo,
            "estado": tramite.estado,
            "nivel_educativo_id": tramite.nivel_educativo_id,
            "municipio_id": tramite.municipio_id,
            "asunto_id": tramite.asunto_id
        } for tramite in tramites]

    @staticmethod
    def actualizar_tramite(id, municipio_id, nombrecomp=None, curp=None, nombre=None, paterno=None, materno=None,
                           telefono=None, celular=None, correo=None, estado=None, nivel_educativo_id=None,
                           asunto_id=None):
        tramite = session.query(Tramite).filter_by(id=id, municipio_id=municipio_id).first()
        if tramite:
            if nombrecomp is not None:
                tramite.nombrecomp = nombrecomp
            if curp is not None:
                tramite.curp = curp
            if nombre is not None:
                tramite.nombre = nombre
            if paterno is not None:
                tramite.paterno = paterno
            if materno is not None:
                tramite.materno = materno
            if telefono is not None:
                tramite.telefono = telefono
            if celular is not None:
                tramite.celular = celular
            if correo is not None:
                tramite.correo = correo
            if estado is not None:
                tramite.estado = estado
            if nivel_educativo_id is not None:
                tramite.nivel_educativo_id = nivel_educativo_id
            if asunto_id is not None:
                tramite.asunto_id = asunto_id
            session.commit()

    @staticmethod
    def eliminar_tramite(id, municipio_id):
        tramite = session.query(Tramite).filter_by(id=id, municipio_id=municipio_id).first()
        if tramite:
            session.delete(tramite)
            session.commit()

Base.metadata.create_all(engine)