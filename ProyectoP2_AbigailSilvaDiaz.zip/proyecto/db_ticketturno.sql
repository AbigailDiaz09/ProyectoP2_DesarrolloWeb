create database db_ticketturno;
use db_ticketturno;
CREATE TABLE tramite (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombrecomp VARCHAR(255),
    curp VARCHAR(18),
    nombre VARCHAR(100),
    paterno VARCHAR(100),
    materno VARCHAR(100),
    telefono VARCHAR(10),
    celular VARCHAR(10),
    correo VARCHAR(100),
    nivel_educativo_id INT,  -- Referencia a la tabla niveles_educativos
    municipio_id INT,        -- Referencia a la tabla municipios
    asunto_id INT,           -- Referencia a la tabla asuntos
    FOREIGN KEY (nivel_educativo_id) REFERENCES niveles_educativos(id),
    FOREIGN KEY (municipio_id) REFERENCES municipios(id),
    FOREIGN KEY (asunto_id) REFERENCES asuntos(id)
);

CREATE TABLE niveles_educativos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nivel VARCHAR(50) NOT NULL
);

CREATE TABLE municipios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    municipio VARCHAR(100) NOT NULL
);

CREATE TABLE asuntos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asunto VARCHAR(100) NOT NULL
);

CREATE TABLE admins (
    user VARCHAR(20) PRIMARY KEY,
    pass VARCHAR(80) NOT NULL
);