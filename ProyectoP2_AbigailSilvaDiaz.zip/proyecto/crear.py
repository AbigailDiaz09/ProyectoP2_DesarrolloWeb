from bd_ticketturno import NivelEducativo, Municipio, Asunto, Tramite, Admin
if len(NivelEducativo.listar_niveles())==0:
    NivelEducativo.crear_nivel("1er semestre")
    NivelEducativo.crear_nivel("2do semestre")
    NivelEducativo.crear_nivel("3er semestre")
    NivelEducativo.crear_nivel("4to semestre")
    NivelEducativo.crear_nivel("5to semestre")
    NivelEducativo.crear_nivel("6to semestre")

if len(Municipio.listar_municipios())==0:
    Municipio.crear_municipio("Saltillo")
    Municipio.crear_municipio("Arteaga")
    Municipio.crear_municipio("Ramos")

if len(Asunto.listar_asuntos())==0:
    Asunto.crear_asunto("Inscripción")
    Asunto.crear_asunto("Baja temporal")
    Asunto.crear_asunto("Baja definitiva")

Admin.crear_admin("admin", "contraseña")