const valida_login = () => {
    const js_captcha = document.getElementById("captcha").value;
    const js_usuario = document.getElementById("usuario").value;
    const js_contraseña = document.getElementById("password").value;
    if (js_captcha != "Td4eva"){
        alert("captcha incorrecto");
        return false;
    }
    else if(js_usuario.length == 0){
        alert("Escriba un usuario");
        return false;
    }
    else if(js_contraseña.length == 0){
        alert("Escriba una contraseña");
        return false;
    }
    else{
        return true;
    }
}
