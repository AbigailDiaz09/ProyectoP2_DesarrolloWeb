const valida_forma = () => {
    const js_nombrecomp = document.getElementById("nombrecomp").value;
    const js_curp = document.getElementById("curp").value;
    const js_nombre = document.getElementById("nombre").value;
    const js_paterno = document.getElementById("paterno").value;
    const js_materno = document.getElementById("materno").value;
    const js_telefono = document.getElementById("telefono").value;
    const js_celular = document.getElementById("celular").value;
    const js_correo = document.getElementById("correo").value;
    const js_nivelingresar = document.getElementById("nivelaingresar").value; 
    const js_municipio = document.getElementById("municipio").value;
    const js_asunto = document.getElementById("asunto").value;
  
    if (js_nombrecomp.length == 0) {
        alert("El nombre completo no debe estar vacío");
        return false;
    } else if (js_nombrecomp.length < 4) {
        alert("El nombre completo debe tener mínimo 3 caracteres");
        return false;
    } else if (js_curp.length == 0) {
        alert("El CURP no debe estar vacío");
        return false;
    } else if (js_curp.length < 18) {
        alert("El CURP debe tener 18 caracteres");
        return false;
    } else if (js_nombre.length == 0) {
        alert("El nombre no debe estar vacío");
        return false;
    } else if (js_nombre.length < 4) {
        alert("El nombre debe tener mínimo 3 caracteres");
        return false;
    } else if (js_paterno.length == 0) {
        alert("El apellido paterno no debe estar vacío");
        return false;
    } else if (js_paterno.length < 4) {
        alert("El apellido paterno debe tener mínimo 3 caracteres");
        return false;
    } else if (js_materno.length == 0) {
        alert("El apellido materno no debe estar vacío");
        return false;
    } else if (js_materno.length < 4) {
        alert("El apellido materno debe tener mínimo 3 caracteres");
        return false;
    } else if (js_telefono.length == 0) {
        alert("El teléfono no debe estar vacío");
        return false;
    } else if (js_telefono.length < 8) {
        alert("El teléfono debe tener mínimo 7 caracteres");
        return false;
    } else if (js_celular.length == 0) {
        alert("El celular no debe estar vacío");
        return false;
    } else if (js_celular.length < 10) {
        alert("El celular debe tener mínimo 10 caracteres");
        return false;
    } else if (js_correo.length == 0) {
        alert("El correo electrónico no debe estar vacío");
        return false;
    } else if (js_nivelingresar === "") {
        alert("Debe seleccionar un nivel de interés");
        return false;
    } else if (js_municipio === "") {
        alert("Debe seleccionar un municipio");
        return false;
    } else if (js_asunto === "") {
        alert("Debe seleccionar un asunto de interés");
        return false;
    } else {
        alert("Formulario enviado");
        return true;
    }
};

const valida_buscar = () => {
    const js_numero = document.getElementById("numero_turno").value;
    const js_municipio = document.getElementById("municipio_turno").value;

    if(js_numero.length == 0){
        alert('Coloque un numero de turno');
        return false;
    }
    else if(js_numero<=0){
        alert('No se acpeta este numero de turno');
        return false;
    }
    else if(js_municipio === ""){
        alert('Seleccione un municipio')
        return false;
    }
    else{
        return true;
    }
}